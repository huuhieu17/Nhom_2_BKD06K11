</div>
<div id="footer">
	<center>Copyright &copy; Huu Hieu 2021</center>
</div>
</div>
<script>
function menu() {
  var x = document.getElementById("header");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
<script type="text/javascript">
  window.onscroll = function() {myFunction()};

function myFunction() {
  if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
    document.getElementById("header").style.position = "sticky";
  } else {
     document.getElementById("header").style.position = "relative";
  }
  //  if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
  //   document.getElementById("footer").style.position = "sticky";
  // } else {
  //    document.getElementById("footer").style.position = "fixed";
  // }
 
 
}
</script>

<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
</body>
</html>