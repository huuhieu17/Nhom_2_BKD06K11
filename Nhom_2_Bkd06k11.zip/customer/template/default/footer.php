
</div>
	<div id="footer">
		<hr>
		<style>
			h3{
				margin: 3% 0;
			}
			#footer{
				padding: 0 8%;
				color: white;
				background: #333f48;
				clear: both;
				width: 100%;
				height: 30vh;
			}
			#fleft{
				text-align: left;
				width: 30%;
				float: left;
			}
			#fleft img{

				width: 40%;
			}
			#fleft p{
				font-size: 13px;
			}
			#fcenter{
				width: 50%;
				float: left;
			}
			#fcenter p{
				font-size: 13px;
			}
			#fright{
				width: 20%;
				float:left;
				
			}
			#fright p{
				font-size: 13px;
			}

		</style>
		<div id="fleft">
			<h3>HGroup Cooperation</h3>
			
			<p>
				<br><br>
				<b>Phone:</b> +84373273733 <br><br>
				<b>Address:</b> 379 Street, Hamlet 2, Dong Du Commune, Gia Lam District, Ha Noi City. <br><br>
				<b>Email:</b> huuhieu1711@gmail.com
			</p>
		</div>
		<div id="fcenter">
			<h3></h3>
				
		</div>
		<div id="fright">
			<h3>About Us</h3>
			<p>
				Copyright HuuHieu &copy; 2020
			</p>		
		</div>

	</div>
	<script>
		// navbar3
		function drop(){
  var x = document.getElementById("header");
  if(x.className === "nav"){
    x.className+= " temp";
  } else {
    x.className = "nav";
  }
  
}
	</script>
</body>
</html>