<?php 
header("Location:index.php?s=home");
?>