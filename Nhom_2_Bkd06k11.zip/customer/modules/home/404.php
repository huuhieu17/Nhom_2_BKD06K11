<?php 
require_once('customer/template/version1/header.php');
$subTitle = "404 - PAGE NOT FOUND";
require_once('customer/template/version1/footer.php'); ?>

?>