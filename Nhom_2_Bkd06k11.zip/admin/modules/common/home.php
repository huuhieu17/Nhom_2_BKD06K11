<?php 
require_once 'template/header.php';
require_once('././config/check_login.php');
echo "abc";
require_once 'template/footer.php';
?>