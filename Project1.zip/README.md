# Hstore
## Website bán quần áo <br>
/* Đối tương: Người mua hàng 
### Chức năng:
#### + Visitor / User: 
- Xem hàng, Thêm vào giỏ hàng, Đăng Ký, Đăng Nhập,... 
#### + Administrator: 
- Quản lý sản phẩm ( Thêm, sửa, xóa) 
- Thay đổi thông tin người dùng 
- Quản lý đơn hàng (Chấp nhận/ Hủy đơn)
 */
 ### Demo:
 #### Admin
 -username: admin
 -pass: 1234
