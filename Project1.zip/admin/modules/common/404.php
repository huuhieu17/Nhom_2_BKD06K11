<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <meta http-equiv="refresh" content="4;url=?modules=common" />
	<title>404 - Not Found</title>
</head>
<body>
	<center>
		<h1>Page Not EXIST!</h1>
		<p>Page will redirect after 4 seconds</p>
	</center>
	
</body>
</html>